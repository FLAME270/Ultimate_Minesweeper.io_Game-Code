﻿SELECT bible.t AS Text, bible.b, bible.c AS Chapter, bible.v AS Verse
, key_english.n AS Book, key_english.t AS Testamate, key_english.g,
key_genre_english.g, key_genre_english.n AS Genre
FROM t_kjv bible
JOIN key_english 
ON bible.b = key_english.b
JOIN key_genre_english
ON key_english.g = key_genre_english.g
WHERE bible.t LIKE '%wisdom%' AND key_english.t ='OT'
ORDER BY bible.b, Chapter, Verse