﻿/*Tyler Wiggins
 * This is my own work
 * Bible Benchmark
 * Did assighnment in class
 * Helped by Bill Huges*/

using BibleVerseApp.Models;
using BibleVerseApp.Services.DataAccess;
using System.Collections.Generic;

namespace BibleVerseApp.Services.Business
{
    public class BibleBusiness
    {
        /// <summary>
        /// Method that gets all the verses related to the searched term
        /// then returns it to the controller
        /// </summary>
        /// <param name="passSearchCriteria"></param>
        /// <returns></returns>
        public IEnumerable<BibleVerse> GetAllVerses(VerseSearch passSearchCriteria)
        {
            BibleData PassToDataLayer = new BibleData();
            IEnumerable<BibleVerse> AllVerses = PassToDataLayer.getBibleVerses(passSearchCriteria);

            return AllVerses;
        }
    }
}