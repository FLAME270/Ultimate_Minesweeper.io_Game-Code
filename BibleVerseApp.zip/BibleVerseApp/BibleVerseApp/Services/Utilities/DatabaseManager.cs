﻿/*Tyler Wiggins
 * This is my own work
 * Bible Benchmark
 * Did assighnment in class
 * Helped by Bill Huges*/

namespace BibleVerseApp.Services.Utilities
{
    public class DatabaseManager
    {
        //Define class Atribute
        public string connString { get; set; }

        /// <summary>
        /// Constructor to set the connection string
        /// </summary>
        public DatabaseManager()
        {
            this.connString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bible;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        }
    }
}