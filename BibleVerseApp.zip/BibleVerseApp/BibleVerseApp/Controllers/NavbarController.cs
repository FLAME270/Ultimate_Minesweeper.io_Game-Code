﻿using Microsoft.AspNetCore.Mvc;

namespace BibleVerseApp.Controllers
{
    public class NavbarController : Controller
    {
        public IActionResult About()
        {
            return About();
        }

        public IActionResult DailyVerse()
        {
            return DailyVerse();
        }
    }
}