﻿/*Tyler Wiggins
 * This is my own work
 * Bible Benchmark
 * Did assighnment in class
 * Helped by Bill Huges*/

using BibleVerseApp.Models;
using BibleVerseApp.Services.Business;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace BibleVerseApp.Controllers
{
    public class BibleController : Controller
    {
        /// <summary>
        /// Initial defalt veiw
        /// </summary>
        /// <returns></returns>
        public IActionResult Index()
        {
            List<BibleVerse> searchResults = new List<BibleVerse>();
            return View(searchResults);
        }

        [HttpPost]
        public IActionResult Index([Bind] VerseSearch objSearch)
        {
            //gets list from BibleVerse class
            List<BibleVerse> searchResults = new List<BibleVerse>();
            //if the model state is valid, return all the search results in a new view
            if (ModelState.IsValid)
            {
                BibleBusiness sendSearchCrit = new BibleBusiness();
                searchResults = sendSearchCrit.GetAllVerses(objSearch).ToList();

                return View(searchResults);
               
            }
            //Returns the search results
            return View(searchResults);
        }
    }
}