﻿/*Tyler Wiggins
 * This is my own work
 * Bible Benchmark
 * Did assighnment in class
 * Helped by Bill Huges*/

namespace BibleVerseApp.Models
{
    public class VerseSearch
    {
        //variables
        public string Testament { get; set; }

        public string BibleVersion { get; set; }
        public string Text { get; set; }
    }
}