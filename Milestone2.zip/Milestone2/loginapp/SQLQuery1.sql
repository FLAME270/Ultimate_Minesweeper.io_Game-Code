﻿select * from Users
insert into users(username, password) values ('ram', 'ramsubhi97')