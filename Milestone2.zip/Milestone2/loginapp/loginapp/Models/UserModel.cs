﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace loginapp.Models
{
    public class UserModel
    {

        public String Username { get; set; }

        public String Password { get; set; }




    }
}
