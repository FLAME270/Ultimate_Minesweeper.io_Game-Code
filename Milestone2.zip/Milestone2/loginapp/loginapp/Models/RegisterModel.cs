﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace loginapp.Models
{
    public class RegisterModel
    {


   
        public String username { get; set; }

        public String password { get; set; }

        public String firstname { get; set; }

        public String lastname { get; set; }

        public int age { get; set; }

        public String address { get; set; }

        public String emailaddress { get; set; }

                  
        public String sex { get; set; }


        public RegisterModel()
        {
            age = -1;
            username = "nothing";
            password = "nothing";
            firstname = "nothing";
            lastname = "nothing";
            address = "nothing";
            emailaddress = "nothing";
            sex = "nothing";
        }

        public RegisterModel(string username, string password, string firstname, string lastname, int age, string address, string emailaddress, string sex)
        {
            this.username = username;
            this.password = password;
            this.firstname = firstname;
            this.lastname = lastname;
            this.age = age;
            this.address = address;
            this.emailaddress = emailaddress;
            this.sex = sex;
        }
    }
}
