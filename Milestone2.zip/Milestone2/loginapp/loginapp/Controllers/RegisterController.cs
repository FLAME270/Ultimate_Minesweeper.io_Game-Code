﻿using loginapp.Models;
using loginapp.Services.Data;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace loginapp.Controllers
{
    public class RegisterController : Controller
    {


      public ActionResult Create()
        {
            return View("CreateForm");
        }

        
        public IActionResult makeCreate(RegisterModel rgmodel)
        {
            RegisterDAO rgdao = new RegisterDAO();
         rgdao.Create(rgmodel);
     
        

            
            return View("Create", rgmodel);
        }

    

    }
}
