﻿using loginapp.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace loginapp.Services.Data
{
    public class RegisterDAO
    {

        string connectionstringforregister = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog = dbUser; Integrated Security = True; Connect Timeout = 30; Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";



        public List<RegisterModel> getall()
        {
            List<RegisterModel> list = new List<RegisterModel>();
            using (SqlConnection connection = new SqlConnection(connectionstringforregister))
            {

                string sqlquery = "SELECT * FROM dbo.Users";

                SqlCommand command = new SqlCommand(sqlquery, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        RegisterModel registermodel = new RegisterModel();
                        registermodel.age = reader.GetInt32(0);
                        registermodel.firstname = reader.GetString(1);
                        registermodel.lastname = reader.GetString(2);
                        registermodel.username = reader.GetString(3);
                        registermodel.password = reader.GetString(4);
                        registermodel.emailaddress = reader.GetString(5);
                        registermodel.sex = reader.GetString(6);
                        registermodel.address = reader.GetString(7);

                        list.Add(registermodel);
                    }
                }


            }

            return list;
        }

        public int Create(RegisterModel rgmodel)
        {
        
            using (SqlConnection connection = new SqlConnection(connectionstringforregister))
            {

                string sqlquery = "INSERT INTO  dbo.Users Values(@age, @firstName, @lastName, @userName, @password, @emailAddress, @Sex, @Address)";



                SqlCommand command = new SqlCommand(sqlquery, connection);


                command.Parameters.Add("@age", System.Data.SqlDbType.Int).Value = rgmodel.age;
                command.Parameters.Add("@firstName", System.Data.SqlDbType.VarChar, 1000).Value = rgmodel.firstname;
                command.Parameters.Add("@lastName", System.Data.SqlDbType.VarChar, 1000).Value = rgmodel.lastname;
                command.Parameters.Add("@userName", System.Data.SqlDbType.VarChar, 1000).Value = rgmodel.username;
                command.Parameters.Add("@password", System.Data.SqlDbType.VarChar, 1000).Value = rgmodel.password;
                command.Parameters.Add("@emailAddress", System.Data.SqlDbType.VarChar, 1000).Value = rgmodel.emailaddress;
                command.Parameters.Add("@Sex", System.Data.SqlDbType.VarChar, 1000).Value = rgmodel.sex;
                command.Parameters.Add("@Address", System.Data.SqlDbType.NVarChar, 1000).Value = rgmodel.address;

                connection.Open();


                int newid = command.ExecuteNonQuery();

                return newid;
            
            }
        }

    }
}