﻿using loginapp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace loginapp.Services.Data
{
    public class SecurityDAO

    {

        string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Test;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

       


        internal bool FindByUser(UserModel user)
        {

            bool sucess = false;
            //if(user.Username == "ram" && user.Password == "ramsubhi97")
            //{
            //    return true;


            //}
            //else
            //{
            //    return false;

            // another way 
            //   return (user.Username == "ram" && user.Password == "ramsubhi97");


            // start by assuming nothing is found



            // write sql expression 

            string queryString = "SELECT * FROM dbo.Users WHERE username = @Username AND password = @Password";

            // create and open the connection to the databse inside using block


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command =  new SqlCommand(queryString, connection);

                command.Parameters.Add("@Username", System.Data.SqlDbType.VarChar, 50).Value = user.Username;

                command.Parameters.Add("@Password", System.Data.SqlDbType.VarChar, 50).Value = user.Password;

                // open the databse and run the command

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        sucess = true;

                    }
                    else
                    {
                        sucess = false;
                    }

                }

                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
                
                }

            return sucess;
            }


        }
    
}
    

