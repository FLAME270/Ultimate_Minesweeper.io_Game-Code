﻿//Tyler Wiggins
//This is my own work
using ButtonGridApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ButtonGridApp.Controllers
{
    public class ButtonController : Controller
    {
        static List<ButtonModel> buttons = new List<ButtonModel>();
        Random rnd = new Random();
        //sets the grid size
        const int GRID_SIZE = 25;
        public IActionResult Index()
        {
            if (buttons.Count < GRID_SIZE)
            {
                for (int i = 0; i < GRID_SIZE; i++)
                {
                    buttons.Add(new ButtonModel { Id = i, ButtonState = rnd.Next(5) });
                }
            }
 /*            buttons.Add(new ButtonModel { Id = 0,                         ButtonState=0 });
            buttons.Add(new ButtonModel { Id = 1, ButtonState = 1 });
            buttons.Add(new ButtonModel { Id = 2, ButtonState = 2 });
            buttons.Add(new ButtonModel { Id = 3, ButtonState = 3 });
            buttons.Add(new ButtonModel { Id = 4, ButtonState = 4 });
            buttons.Add(new ButtonModel { Id = 5, ButtonState = 5 });*/

            return View("Index", buttons);
        }
        public IActionResult HandleButtonClick(string buttonNumber)
        {
            int bn = int.Parse(buttonNumber);

            buttons.ElementAt(bn).ButtonState = (buttons.ElementAt(bn).ButtonState + 1) % 4;
            return View("Index", buttons);
        }

        public IActionResult ShowOneButton(int buttonNumber)
        {
            //make buttons elements and return the button state
            buttons.ElementAt(buttonNumber).ButtonState = (buttons.ElementAt(buttonNumber).ButtonState + 1) % 4;

            //Save the buttons
            string buttonString = RenderRazorViewToString(this, "ShowOneButton", buttons.ElementAt(buttonNumber));

            //Generate a win or lose based on the button color
            bool isWin = true;

            for(int i=0; i < buttons.Count; i++ )
            {
                if (buttons.ElementAt(i).ButtonState != buttons.ElementAt(0).ButtonState)
                    isWin = false;
            }
            string messageString = "";
            //returns if win is true or not
            if (isWin == true)
            {
                messageString = "Congratulations! all of the buttons are the same color :)</p>";
            }
            else
            {
                messageString = "<p>Not all of the buttons are the same color. See if you can make them match.</p<";
            }

            //puts the message string into a var and sends the var to a json file
            var package = new { part1 = buttonString, part2 = messageString };

            //send json results
            return Json(package);


            //returns a partial view  
          return PartialView(buttons.ElementAt(buttonNumber));
        }

        public static string RenderRazorViewToString(Controller controller, string viewName, object model = null)
        {
            using (var sw = new System.IO.StringWriter())
            {
                //Makes a view engine that uses a string writer
                IViewEngine veiwEngine = controller.HttpContext.RequestServices.GetService(typeof(ICompositeViewEngine)) as CompositeViewEngine;

                ViewEngineResult viewResult = veiwEngine.FindView(controller.ControllerContext, viewName, false);
                //initializes the context
                ViewContext viewContext = new ViewContext(
                    controller.ControllerContext,
                    viewResult.View,
                    controller.ViewData,
                    controller.TempData,
                    sw, new HtmlHelperOptions()
                    );
                //A task that renders the view
                viewResult.View.RenderAsync(viewContext);
                return sw.GetStringBuilder().ToString();
            }
        }

    }
}
