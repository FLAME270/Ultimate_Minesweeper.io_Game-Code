﻿
$(function () {
    console.log("page is ready!!!");

/* $(".game-button").click(function (event) {*/

    $(document).on("click", ".game-button", function (event) {
        event.preventDefault();

        var buttonNumber = $(this).val();
        console.log("Button number " + buttonNumber + " was clicked!");
        doButtonUpdate(buttonNumber);
    })


function doButtonUpdate(buttonNumber)
{
    $.ajax({
        dataType: "json",
        method: 'POST',
        url: '/button/ShowOneButton',
        data: {
        "buttonNumber": buttonNumber
    },
        success: function (data) {
            console.log(data);
            $("#" + buttonNumber).html(data.part1);
            $("#messageArea").html(data.part2);
        }
    })
    }
})