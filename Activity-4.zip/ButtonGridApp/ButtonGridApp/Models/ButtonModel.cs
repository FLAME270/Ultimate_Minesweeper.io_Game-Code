﻿//Tyler Wiggins
//This is my own work
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ButtonGridApp.Models
{
    public class ButtonModel
    { 
        public int Id { get; set; }
        public int ButtonState { get; set; }
    }
}
