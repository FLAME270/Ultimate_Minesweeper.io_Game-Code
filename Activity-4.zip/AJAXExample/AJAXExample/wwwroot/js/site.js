﻿$(function () {
    console.log("page is ready");

    $("#selectCustomers").click(function(event) {
        event.preventDefault();
        console.log("select costomer button was clicked");

        $.ajax({
          
            dataType: "text/plain",
            url: 'customer/ShowOnePerson',
            data: $("form").serialize(),
            success: function (data) {
                console.log("Here is your info");
                $("#customerInformationArea").html(data);
            }
        });
    });
});