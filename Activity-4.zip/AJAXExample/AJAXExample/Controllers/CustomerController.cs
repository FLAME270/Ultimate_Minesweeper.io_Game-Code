﻿//Tyler Wiggins
//This is my own work
using AJAXExample.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AJAXExample.Controllers
{
    public class CustomerController : Controller
    {
        //Makes a list of customers
        List<CustomerModel> customers = new List<CustomerModel>();
        public CustomerController()
        {
            //add new customers to a list
            customers.Add(new CustomerModel(0, "Tommy", 56));
            customers.Add(new CustomerModel(1, "Sarah", 20));
            customers.Add(new CustomerModel(2, "David", 5));
            customers.Add(new CustomerModel(3, "Billy", 60));
            customers.Add(new CustomerModel(4, "Shad ", 25));
            customers.Add(new CustomerModel(5, "Wendy", 15));
        }
        public IActionResult Index()
        {
            return View(customers);
        }

        public IActionResult ShowOnePerson(int Id)
        {
            return PartialView(customers.FirstOrDefault(c => c.Id == Id));
        }
    }
}
