﻿//Tyler Wiggins
//This is my own work
using FoodApp.Models;
using FoodApp.Services;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace FoodApp.Controllers
{
    public class ProductsController : Controller
    {
        private ProductsDAO repository;

        public IActionResult Index()
        {
            ProductsDAO product = new ProductsDAO();

            return View(product.GetAllProducts());

            /*          HardCodedSampleDataRepository hardCodedSampleDataRepository = new HardCodedSampleDataRepository();

                      return View(hardCodedSampleDataRepository.GetAllProducts());*/
        }

        public IActionResult SearchResults(string searchTerms)
        {
            ProductsDAO products = new ProductsDAO();

            List<ProductModel> productList = products.SearchProducts(searchTerms);
            return View("index", productList);
        }

        public IActionResult ShowDetail(int id)
        {
            ProductsDAO products = new ProductsDAO();
            ProductModel foundProduct = new ProductModel();
            return View(foundProduct);
        }

        public IActionResult Edit(int id)
        {
            ProductsDAO products = new ProductsDAO();
            ProductModel foundProduct = new ProductModel();
            return View("ShowEdit", foundProduct);
        }

        public IActionResult ProcessEdit(ProductModel product)
        {
            ProductsDAO products = new ProductsDAO();
            products.Update(product);
            return View("Index", products.GetAllProducts());
        }

        public IActionResult Delete(int Id)
        {
            ProductsDAO products = new ProductsDAO();
            ProductModel product = products.GetProductById(Id);
            products.Delete(product);

            return View("Index", products.GetAllProducts());
        }

        public IActionResult searchForm()
        {
            return View();
        }

        public IActionResult ProcessEditReturnOneItem(ProductModel product)
        {
            repository.Update(product);
            return PartialView("_productCard", repository.GetProductById(product.Id));
        }
    }
}

/*      public IActionResult Message()
      {
          return View("message");
      }

      public IActionResult Welcome(string name, int secretNumber = 13)
      {
          vi
      }*/