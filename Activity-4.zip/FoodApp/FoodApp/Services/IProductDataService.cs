﻿//Tyler Wiggins
//This is my own work
using FoodApp.Models;
using System.Collections.Generic;

namespace FoodApp.Services
{
    internal interface IProductDataService
    {
        List<ProductModel> GetAllProducts();

        List<ProductModel> SearchProducts(string searchTerm);

        int Insert(ProductModel product);

        int Update(ProductModel product);

        int Delete(ProductModel product);
    }
}