﻿//Tyler Wiggins
//This is my own work
using Bogus;
using FoodApp.Models;
using System.Collections.Generic;

namespace FoodApp.Services
{
    public class HardCodedSampleDataRepository
    {
        public List<ProductModel> GetAllProducts()
        {
            List<ProductModel> productsList = new List<ProductModel>();
            if (productsList.Count == 0)
            {
                productsList.Add(new ProductModel { Id = 1, Name = "Mouse Pad", Price = 5.99m, Description = "Brand new lighning desighn mouse pad" });

                productsList.Add(new ProductModel { Id = 2, Name = "Alienware laptop", Price = 1500.69m, Description = "Alienware laptop with core i7 intel and 32GB's of ram" });

                productsList.Add(new ProductModel { Id = 3, Name = "Beats headphones- white", Price = 200.00m, Description = "Beat headphones with high quality sound" });

                productsList.Add(new ProductModel { Id = 4, Name = "Alexa speaker", Price = 35.00m, Description = "Connect with alexa and get more with Amazon prime." });

                productsList.Add(new ProductModel { Id = 5, Name = "Pizza cutter", Price = 5.00m, Description = "Super sharp blade to cut right through your pizza" });

                for (int i = 0; i < 100; i++)
                {
                    productsList.Add(new Faker<ProductModel>()
                        .RuleFor(p => p.Id, i + 5)
                        .RuleFor(p => p.Name, f => f.Commerce.ProductName())
                         .RuleFor(p => p.Price, f => f.Random.Decimal(100))
                         .RuleFor(p => p.Description, f => f.Rant.Review()));
                }
            }

            return productsList;
        }
    }
}