﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.
//Tyler Wiggins
//This is my own work
// Write your JavaScript code.
$(function () {
    $(document).on("click", ".edit-product-button", function (event) {
        event.preventDefault();

        var myProductId = $(this).data('id');
        var myProductName = $(this).parent().find('.product-name').html();
        var myProductPrice = $(this).parent().find('.product-price').html();
        var myProductDescription = $(this).parent().find('.product-description').html();

        console.log("Clicked button #" + myProductId);
        console.log("Name = " + myProductName);
        console.log("Price = " + myProductPrice);
        console.log("Description = " + myProductDescription);

        $(".modal-diolog #Id").val(myProductId);
        $(".modal-diolog #Name").val(myProductName);
        $(".modal-diolog #Price").val(myProductPrice);
        $(".modal-diolog #Description").val(myProductDescription);
    });

    $("#save-product").click(function () {
        var Product = {
            "Id": $('#Id').val(),
            "Name": $('#Name').val(),
            "Price": $('#Price').val(),
            "Description": $('#Description').val()
        };
        console.log(Product);
        doProductUpdate(product);

        function doProductUpdate(product) {
            $.ajax({
                datatype: "json",
                url: '/products/ProcessEditReturnOneItem',
                data: product,
                success: function (data) {
                    console.log(data);

                    $("card-number-" + product.Id).html(data);
                }
            });
        };
    });
});