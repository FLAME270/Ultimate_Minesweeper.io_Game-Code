﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AppointmentMaker.Models
{
    public class AppointmentModel
    {

        //getters and setters with data validation
        [Required]
        [DisplayName("Patient's full name")]
        [StringLength(20, MinimumLength = 4)]
        public string patientName { get; set; }
        [DataType(DataType.Date)]
        [Required]
        [DisplayName("Patient's appointment date")]
        public DateTime dateTime { get; set; }
        [DataType(DataType.Currency)]
        [Required]
        [DisplayName("Patient's net worth")]
       
        public decimal PatientNetWorth { get; set; }
        [Required]
        [DisplayName("Doctors last name")]
        public string DoctorName { get; set; }
        [Range(1, 10)]
        [Required]
        [DisplayName("Pain level (1 being low and 10 being high)")]
        public int PainLevel { get; set; }
        [StringLength(50, MinimumLength = 4)]
        [Required]
        [DisplayName("Patient's Street Address")]
        public string Street { get; set; }
        [StringLength(50, MinimumLength = 4)]
        [Required]
        [DisplayName("Patient's City")]
        public string City { get; set; }
        [DataType(DataType.PostalCode)]
        [Required]
        [DisplayName("Patient's Zip code")]
        public int ZIPcode { get; set; }
        [DataType(DataType.EmailAddress)]
        [Required]
        [DisplayName("Patient's email address")]
        public string email { get; set; }
        [DataType(DataType.PhoneNumber)]
        [Required]
        [DisplayName("Patient's phone number")]
        public int phone { get; set; }

     

       
        //constructor
        public AppointmentModel(string patientName, DateTime dateTime, decimal patientNetWorth, string doctorName, int painLevel, string street, string city, int zIPcode, string email, int phone)
        {
            this.patientName = patientName;
            this.dateTime = dateTime;
            PatientNetWorth = patientNetWorth;
            DoctorName = doctorName;
            PainLevel = painLevel;
            Street = street;
            City = city;
            ZIPcode = zIPcode;
            this.email = email;
            this.phone = phone;
        }
        //public declaration
        public AppointmentModel()
        {

        }

    }
}
