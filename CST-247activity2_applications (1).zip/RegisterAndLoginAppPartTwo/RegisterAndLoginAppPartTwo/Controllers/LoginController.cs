﻿using Microsoft.AspNetCore.Mvc;
using RegisterAndLoginAppPartTwo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RegisterAndLoginAppPartTwo.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public  IActionResult ProcessLogin(UserModel user)
        {
            SecurityService securityService =new SecurityService();

            if (securityService.isValid(user))
                return View("LoginSuccess", user);
            else
                return View("LoginFailed", user);

           /* if(user.UserName == "BillGates" && user.Password == "MoneyBags")
            {
                return View("LoginSuccess", user);
            }
            else
            {
                return View("LoginFailed", user);
            }*/
        }
    }
}
