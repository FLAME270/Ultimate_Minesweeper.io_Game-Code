﻿using RegisterAndLoginAppPartTwo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RegisterAndLoginAppPartTwo
{
    public class SecurityService
    {
        SecurityDAO SecurityDAO = new SecurityDAO();

        public bool isValid(UserModel user)
        {
            return SecurityDAO.FindUserByNameAndPassword(user);
        }

        /*List<Models.UserModel> knownUsers = new List<UserModel>();
        public SecurityService()
        {
            knownUsers.Add(new UserModel { Id = 0, UserName = "Elon", Password = "Musk" });

            knownUsers.Add(new UserModel { Id = 0, UserName = "Tyler", Password = "Flame" });

            knownUsers.Add(new UserModel { Id = 0, UserName = "Bill", Password = "Hughes" });

            knownUsers.Add(new UserModel { Id = 0, UserName = "Ducky", Password = "Quackens" });
        }

        public bool IsValid(UserModel user)
        {
            return knownUsers.Any(x => x.UserName == user.UserName && x.Password == user.Password);
        }*/
    }
}
