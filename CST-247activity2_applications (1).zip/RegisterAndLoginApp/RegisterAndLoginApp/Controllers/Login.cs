﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.Web.CodeGeneration.Contracts.Messaging;
using RegisterAndLoginApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xceed.Wpf.Toolkit;

namespace RegisterAndLoginApp.Controllers
{
    public class Login : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult ProcessLogin(UserModel user)
        {
            Console.WriteLine("heya");
            if (user.Username == "BillGates" && user.Password == "BigBucks")
            {
                return View("LoginSuccessful", user);
            }
            else return View("LoginFailed", user);
        }
    }
}
